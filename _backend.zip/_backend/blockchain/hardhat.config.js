import "dotenv/config";

/** @type {import("hardhat/config").HardhatUserConfig} */
const config = {
  solidity: {
    version: "0.8.28",

    settings: {
      evmVersion: "cancun",

      optimizer: {
        enabled: true,
        runs: 200,
      },
    },
  },

  networks: {
    sepolia: {
      type: "http",

      url:
        process.env.SEPOLIA_RPC_URL,

      accounts:
        process.env.DEPLOYER_PRIVATE_KEY
          ? [
              process.env
                .DEPLOYER_PRIVATE_KEY,
            ]
          : [],
    },
  },
};

export default config;